import streamlit as st
from modules.file_organizer import organize_uploaded_files

st.set_page_config(
    page_title="FlowForge AI",
    page_icon="⚙️",
    layout="wide"
)

# -------------------------
# SIDEBAR (SaaS FEEL)
# -------------------------
st.sidebar.title("FlowForge AI")
st.sidebar.markdown("AI Business Automation Suite")

page = st.sidebar.radio(
    "Navigation",
    ["Dashboard", "File Automation", "About"]
)

# -------------------------
# DASHBOARD
# -------------------------
if page == "Dashboard":
    st.title("Welcome to FlowForge AI")
    st.subheader("Automate business workflows in seconds")

    col1, col2, col3 = st.columns(3)

    col1.metric("Automations Available", "1", "+1 coming soon")
    col2.metric("Avg Time Saved", "2-5 hrs", "per batch")
    col3.metric("Efficiency Gain", "+300%", "workflow boost")

    st.markdown("---")

    st.info("Use the sidebar to start automating your files.")

# -------------------------
# FILE AUTOMATION
# -------------------------
elif page == "File Automation":

    st.title("File Automation Engine")
    st.write("Upload files and get a structured, business-ready output.")

    uploaded_files = st.file_uploader(
        "Upload files",
        accept_multiple_files=True
    )

    st.caption("Optional: Add custom rules for organization")

    custom_input = st.text_area(
        "Custom rules (FolderName: .ext,.ext)",
        placeholder="Images: .png,.jpg\nDocs: .pdf,.docx"
    )

    custom_rules = {}

    if custom_input:
        try:
            for line in custom_input.split("\n"):
                if ":" in line:
                    folder, exts = line.split(":")
                    custom_rules[folder.strip()] = [
                        e.strip() for e in exts.split(",")
                    ]
        except:
            st.error("Invalid rule format")

    if st.button("🚀 Run Automation"):
        if uploaded_files:

            with st.spinner("FlowForge AI is processing your files..."):

                zip_path, files, summary, duplicates = organize_uploaded_files(
                    uploaded_files,
                    custom_rules if custom_rules else None
                )

            st.success("Automation Complete")

            st.markdown("### 📊 Results Overview")

            col1, col2 = st.columns(2)

            with col1:
                st.write("**Files Processed**")
                st.write(len(files))

            with col2:
                st.write("**Duplicates Found**")
                st.write(len(duplicates))

            st.markdown("### Breakdown")
            st.json(summary)

            if duplicates:
                st.warning("Duplicate files detected")
                st.write(duplicates)

            with open(zip_path, "rb") as f:
                st.download_button(
                    "⬇️ Download Results Package",
                    f,
                    file_name="flowforge_output.zip"
                )
        else:
            st.error("Please upload files first")

# -------------------------
# ABOUT PAGE
# -------------------------
elif page == "About":
    st.title("About FlowForge AI")

    st.markdown("""
FlowForge AI is a business automation system designed to:

- Eliminate repetitive file management tasks  
- Save hours of manual work  
- Provide structured, automated workflows  
- Help businesses operate more efficiently  

Built with Python + Streamlit
""")
